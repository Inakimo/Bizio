export const ContactData = () => {
  return (
    <div className="rounded-lg p-4 mb-4">
      <h1 className="text-3xl font-bold mb-4">Contact us!</h1>
      <h2 className="text-xl mb-4">Lorem ipsum dolor sit amet.</h2>
      <div className="mb-2">
        <span className="block text-lg mb-2">apsijas@asjapsj.com</span>
        <span className="block text-lg mb-2">98918201890990</span>
        <span className="block text-lg">aisagspi</span>
      </div>
    </div>
  );
};
